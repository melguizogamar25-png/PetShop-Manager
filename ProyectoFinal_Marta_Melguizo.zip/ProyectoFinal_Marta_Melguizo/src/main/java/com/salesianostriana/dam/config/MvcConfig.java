package com.salesianostriana.dam.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class MvcConfig implements WebMvcConfigurer{

	@Override
	public void addViewControllers (ViewControllerRegistry registry) {
		registry.addViewController("/login").setViewName("login");
		
		registry.addViewController("/admin/index").setViewName("admin/index");
		
		registry.addViewController("/user/index").setViewName("user/index");
	}
}
